#def saludo():
 #    print("Hola amiga")
  #   return
#saludo()

#def despedida():
 #  print("Buenas noches, hasta mañana")
 #   return
#despedida()

print("Hola mundo con python")