
#while True:
 #frase = input("Introduce algo: ")
 #if frase == "salir":
  # break
#print(frase)

while True:
    palabra = input("Ingrese una palabra: ")
    if palabra == "Terminar":
        break
print(palabra)