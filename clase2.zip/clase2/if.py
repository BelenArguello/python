#Definir tu edad
#edad = int(input("Digita tu edad: "))
#if edad >= 18:
#    print("Eres mayor")
#else:
 #   print("Eres menor")


#Escribir un programa que pida al usuario una palabra y la muestre 10 veces por pantalla

#palabra = (input("Por favor ingrese una palabra: "))
#for palabra in range(5):
#    print(palabra)

#Escribir un programa que muestre el eco de todo lo que el usuario introduzca hasta que el usuario escriba "Terminar" debe terminar 
#el programa

while True:
 frase = input("Introduce algo: ")
 if frase == "salir":
   break
print(frase)



