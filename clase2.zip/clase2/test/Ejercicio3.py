def saludo():
 print("Buenos dias para todos")

saludo()