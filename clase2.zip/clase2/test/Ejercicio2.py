clubes = ["olimpia", "cerro", "nacional", "guarani", "3 de febrero"]
print(clubes)