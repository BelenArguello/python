#minicalculadora
def sumar_num(x, y):
    return x+y

def restar_num(x, y):
    return x-y

def multiplicar_num(x, y):
    return x*y

def dividir_num(x, y):
    return x/y

while True:
    print("****Bienvenido a la calculadora****")
    print("*******Opciones*******")
    print("1. Sumar")
    print("2. Restar")
    print("3. Multiplicar")
    print("4. Dividir")
    print("5. Salir")

    opcion = input("Digite la opcion 1/2/3/4: ")

    if opcion == '1':
        n1=int(input("Ingrese un numero: "))
        n2=int(input("Ingrese siguiente numero: "))
        print(n1, "+", n2, "=",sumar_num(n1,n2))
    elif opcion == '2':
        n1=int(input("Ingrese un numero: "))
        n2=int(input("Ingrese siguiente numero: "))
        print(n1, "-", n2, "=",restar_num(n1,n2))
    elif opcion == '3':
        n1=int(input("Ingrese un numero: "))
        n2=int(input("Ingrese siguiente numero: "))
        print(n1, "*", n2, "=",multiplicar_num(n1,n2))
    elif opcion == '4':
        n1=int(input("Ingrese un numero: "))
        n2=int(input("Ingrese el siguiente numero: "))
        print(n1, "/", n2, "=", dividir_num(n1,n2))
        
        break