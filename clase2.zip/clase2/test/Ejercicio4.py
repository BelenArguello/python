tabla = 12
inicio = 1
print("*******************************************")
while inicio<=10:
    resultado = tabla*inicio
    print(tabla, "*", inicio, "=", resultado)
    inicio+=1
print("*******************************************")    