#clave = input("Introduce tu clave, por favor: ")
#if clave == "1234" :
 #   print("Clave correcta, puede ingresar")
#else:
#    print("Clave incorrecta, Acceso Denegado")

contraseña = input("Introduce la contraseña, por favor: ")
if contraseña == "250202":
    print("La contraseña es correcta, puede ingresar")
else:
    print("La contraseña es incorrecta, Acceso Denegado")